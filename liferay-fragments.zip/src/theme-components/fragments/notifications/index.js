fetch('/o/headless-admin-workflow/v1.0/workflow-tasks/assigned-to-my-roles?p_auth='+Liferay.authToken)
  .then(response => response.json())
  .then(data =>{

});