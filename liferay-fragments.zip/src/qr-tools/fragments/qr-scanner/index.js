console.group('QR Scanner');
console.log('fragmentElement', fragmentElement);
console.log('configuration', configuration);
console.groupEnd();